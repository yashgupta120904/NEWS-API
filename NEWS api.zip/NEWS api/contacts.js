CONNECTION_STRING = "mongodb+srv://yashcluster:CNILE2RPRgXlualu@yashcluster.pjj7pdb.mongodb.net/contacts?retryWrites=true&w=majority&appName=YashCluster"  
module.exports={CONNECTION_STRING};